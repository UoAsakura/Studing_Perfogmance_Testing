
Каталог с результатами студентов находится в корне проекта.
Или по адресу: Java/Students/src/results_students (для linux).
Исполняемый файл находится так же в корне проекта в формате .jar .
Или по адресам:
 - Java/Students/out/production/Students
 - Java/Students/src
Исполняемый файл, называется Main.class .

Домашняя работа Боярова Евгения Владиславовича.

