package ru.pflb.SMSMOCKHRLINK;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsmockhrlinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
