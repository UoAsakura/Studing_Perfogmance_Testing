package ru.pflb.SMSMOCKHRLINK.services;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


@Service
public class SmsService {
    private final Map<String, String> smsStore = new ConcurrentHashMap<>();

    public void storeSms(String phoneNumber, String code) {
        smsStore.put(phoneNumber, code);
    }

    public String retrieveSms(String phoneNumber) {
        String code = smsStore.get(phoneNumber);
        smsStore.remove(phoneNumber);
        return code;
    }
}
