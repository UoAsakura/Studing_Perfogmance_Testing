package ru.pflb.SMSMOCKHRLINK.services;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


@Service
public class LinksService {
    private final Map<String, String> smsStore = new ConcurrentHashMap<>();

    public void storeLink(String phoneNumber, String link) {
        smsStore.put(phoneNumber, link);
    }

    public String retrieveLink(String phoneNumber) {
        String link = smsStore.get(phoneNumber);
        smsStore.remove(phoneNumber);
        return link;
    }
}
