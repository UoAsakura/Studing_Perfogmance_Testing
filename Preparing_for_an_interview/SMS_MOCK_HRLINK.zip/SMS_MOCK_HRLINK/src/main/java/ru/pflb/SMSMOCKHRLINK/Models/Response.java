package ru.pflb.SMSMOCKHRLINK.Models;

import lombok.*;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Response {

    private List<Message> messages;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Message {
        private String msisdn;
        private String messageId;
        private String internalId;
    }

}