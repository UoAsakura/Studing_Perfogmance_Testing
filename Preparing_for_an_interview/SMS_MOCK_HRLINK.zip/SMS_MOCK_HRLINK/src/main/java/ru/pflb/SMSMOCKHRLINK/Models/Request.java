package ru.pflb.SMSMOCKHRLINK.Models;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Request {

    @Valid
    @NotEmpty
    @NotNull(message = "no messages given")
    private List<Message> messages;

    public String getContent() { return messages.get(0).getContent().getShort_text(); }
    public String getMessageId() { return messages.get(0).getTo().get(0).getMessage_id(); }
    public String getMsisdn() { return messages.get(0).getTo().get(0).getMsisdn(); }

    public String asJson() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(this);
        } catch(JsonProcessingException e) {
            return "{\"error\": \"" + e + "\"}";
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Message {

        @Valid
        @NotNull(message = "content is null")
        private Content content;

        // @Valid - no useful info
        @NotNull(message = "from is null")
        private From from;

        @Valid
        @NotEmpty
        @NotNull(message = "to is null")
        private List<To> to;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Content {

        @NotBlank(message = "shortText is empty")
        @NotNull(message = "shortText is null")
        private String short_text;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class From {

        @NotBlank(message = "smsAddress is empty")
        @NotNull(message = "smsAddress is null")
        private String sms_address;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class To {

        @NotBlank(message = "msisdn is empty")
        @NotNull(message = "msisdn is null")
        private String msisdn;


        @NotBlank(message = "messageId is empty")
        @NotNull(message = "messageId is null")
        private String message_id;

    }

}


/*                                      EXAMPLE OF REQUEST:

    {
       "messages": [
           {
               "content": {
                   // Текст сообщения для отправки уведомления пользователю через "MTC"
                   "shortText": "Код подтверждения заявки на УНЭП: 7158HR-Link"
               },
               "from": {
                   // Наименование отправителя SMS-сообщения, отображаемое получателю
                   "smsAddress": "HR-Link"
               },
               "to": [
                   {
                       // Номер телефона адресата сообщения
                       "msisdn": "79161234567",
                       // Идентификатор сообщения, который генерируется на стороне клиента.
                          Соответствует значению id из таблицы sms_notification
                       "messageId": "057e3262-1638-4e84-8758-e0d20d5541cd"
                   }
               ]
           }
       ]
     }


*/
