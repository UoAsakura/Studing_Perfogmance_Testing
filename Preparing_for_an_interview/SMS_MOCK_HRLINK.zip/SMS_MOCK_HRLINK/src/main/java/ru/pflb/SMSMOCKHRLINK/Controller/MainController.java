package ru.pflb.SMSMOCKHRLINK.Controller;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import ru.pflb.SMSMOCKHRLINK.Models.*;
import ru.pflb.SMSMOCKHRLINK.services.LinksService;
import ru.pflb.SMSMOCKHRLINK.services.SmsService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
@RestController
public class MainController {

    @Autowired
    private SmsService smsService;

    @Autowired
    private LinksService linksService;


    private String REGEX = "(\\d{4})";
    private String LINK_REGEX = "(https?://[^\\s/$.?#].[\\S]*)";


    @PostMapping("${spring.application.SMS_MOCK.endpoint}")
    public Response notification(@RequestBody @Valid Request request) {

        log.info("\u001B[33mReceived message with body:  " + request.asJson() + "\u001B[0m");

        String phoneNumber = request.getMsisdn();
        String content = request.getContent(); // SMS-code is in here
        Matcher matcher = Pattern.compile(REGEX).matcher(content);
        if (matcher.find()) {
            String code = matcher.group(1);
            smsService.storeSms(phoneNumber, code);
            log.info("\u001B[32mCode for " + phoneNumber + ": " + code + "\u001B[0m");
        } else {
            log.info("\u001B[31mCode for " + phoneNumber + " not found in [" + content + "]\u001B[0m");
            Matcher matcher2 = Pattern.compile(LINK_REGEX).matcher(content);
            if (matcher2.find()) {
                String link = matcher2.group(1);
                linksService.storeLink(phoneNumber, link);
                log.info("\u001B[32mFound link for " + phoneNumber + ":  [ " + link + " ]\u001B[0m");
            }
        }
        return createResponse(request.getMessageId(), phoneNumber);
    }


    @GetMapping("${spring.application.SMS_MOCK.codes_endpoint}")
    public String get_code(@RequestParam String phoneNumber) {
        log.info("\u001B[33mReceived request of code for " + phoneNumber + "\u001B[0m");
        String code = smsService.retrieveSms(phoneNumber);
        if (code != null) {
            log.info("\u001B[32mReturning code for " + phoneNumber + ": " + code + "\u001B[0m");
            return code;
        }
        log.info("\u001B[31mCode for " + phoneNumber + " not found\u001B[0m");
        return "Code not found";
    }

    @GetMapping("${spring.application.SMS_MOCK.links_endpoint}")
    public String get_link(@RequestParam String phoneNumber) {
        log.info("\u001B[33mReceived request of link for " + phoneNumber + "\u001B[0m");
        String link = linksService.retrieveLink(phoneNumber);
        if (link != null) {
            log.info("\u001B[32mReturning link for " + phoneNumber + ":  [ " + link + " ]\u001B[0m");
            return link;
        }
        log.info("\u001B[31mLink for " + phoneNumber + " not found\u001B[0m");
        return "Link not found";
    }



    private Response createResponse(String messageId, String msisdn) {
        Response.Message message = new Response.Message(msisdn, messageId, UUID.randomUUID().toString());
        return new Response(new ArrayList<>(List.of(message)));
    }

}
