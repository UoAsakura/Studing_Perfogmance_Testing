package ru.pflb.SMSMOCKHRLINK;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsmockhrlinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsmockhrlinkApplication.class, args);
	}

}
