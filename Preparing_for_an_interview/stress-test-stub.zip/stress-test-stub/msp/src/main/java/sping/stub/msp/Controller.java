package sping.stub.msp;

import ch.qos.logback.classic.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.util.PrivateKeyFactory;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DefaultDigestAlgorithmIdentifierFinder;
import org.bouncycastle.operator.DefaultSignatureAlgorithmIdentifierFinder;
import org.bouncycastle.operator.bc.BcECContentSignerBuilder;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import java.util.Date;



@RestController
public class Controller {

//    private static Logger log = (Logger) LoggerFactory.getLogger(Controller.class);

//    ObjectMapper mapper = new ObjectMapper();

    private static final ConcurrentLinkedQueue<Map<String, String>> queue = new ConcurrentLinkedQueue<>();
    private static final ConcurrentLinkedQueue<Map<String, Object>> queueCert = new ConcurrentLinkedQueue<>();


    private String generateRandomHex(int length, boolean upperCase) {
        Random random = new Random();
        String characters = upperCase ? "0123456789ABCDEF" : "0123456789abcdef";
        return IntStream.range(0, length)
                .map(i -> characters.charAt(random.nextInt(characters.length())))
                .mapToObj(c -> String.valueOf((char) c))
                .collect(Collectors.joining());
    }

    private String generateRandomGuid() {
        return UUID.randomUUID().toString().toUpperCase();
    }


    @PostMapping("/events")
    public ResponseEntity<Map<String, Object>> handleEvents(@RequestBody Map<String, Object> request) {
        List<Map<String, Object>> events = (List<Map<String, Object>>) request.get("events");
        Map<String, Object> firstEvent = events.get(0);
        String code = (String) firstEvent.get("code");
        Map<String, Object> response = new HashMap<>();
        List<Map<String, Object>> responseEvents = new ArrayList<>();

        if ("usig.reg.request".equals(code)) {
            responseEvents.add(handleUsigRegRequest(firstEvent));
        } else if ("usig.token.request".equals(code)) {
            responseEvents.add(handleUsigTokenRequest(firstEvent));
        } else if ("usig.token.activate.request".equals(code)) {
            responseEvents.add(handleUsigTokenActivateRequest(firstEvent));
        } else if ("usig.sign.hash.request".equals(code)) {
            responseEvents.add(handleUsigSignHashRequest(firstEvent));
        }

        response.put("type", "about:blank");
        response.put("title", "Сведения о событиях");
        response.put("events", responseEvents);
        response.put("status", 200);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/events")
    public ResponseEntity<Map<String, Object>> getEvent() throws Exception {
        Map<String, Object> responseEvent = null;
        Map<String, String> queueElement;
        Queue<Map<String, String>> tempQueue = new LinkedList<>();

        while ((queueElement = queue.poll()) != null) {
            String futureTime = queueElement.get("time");
            Instant instant = Instant.parse(futureTime);

            if (instant.isAfter(Instant.now())) {
                tempQueue.add(queueElement);
            } else {
                responseEvent = new HashMap<>();
                String id = generateRandomHex(32, false);
                responseEvent.put("id", id);
                String code = queueElement.get("code");
                String parent = queueElement.get("id");
                responseEvent.put("parent", parent);
                responseEvent.put("code", code);

                if ("usig.reg.response".equals(code)) {
                    responseEvent.put("data", createUsigRegResponseData(queueElement));
                } else if ("usig.token.response".equals(code)) {
                    responseEvent.put("data", createUsigTokenResponseData(queueElement));
                } else if ("usig.token.activate.response".equals(code)) {
                    responseEvent.put("data", createUsigTokenActivateResponseData(queueElement));
                } else if ("usig.sign.hash.response".equals(code)) {
                    responseEvent.put("data", createSugnHashResponseData());
                }

                responseEvent.put("created", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'").format(new Date()));
                responseEvent.put("consumer", Collections.singletonList(generateRandomHex(32, false)));
                break;
            }
        }

        queue.addAll(tempQueue);

        Map<String, Object> response = new HashMap<>();
        response.put("type", "about:blank");
        response.put("title", "Сведения о событиях");

        if (responseEvent != null) {
            response.put("events", Collections.singletonList(responseEvent));
        } else {
            response.put("events", Collections.emptyList());
        }

        response.put("status", 200);

        return ResponseEntity.ok(response);
    }

    private static final String FILE_STORAGE_PATH = "/templates/";

    @GetMapping("/files/{file_uuid}")
    public ResponseEntity<byte[]> getFile(@PathVariable("file_uuid") String fileUuid) {
        ClassLoader classLoader = Controller.class.getClassLoader();

        if (Objects.equals(fileUuid, "00000000-0000-0000-0000-000000000010")) {
            try (InputStream resourceStream = classLoader.getResourceAsStream(FILE_STORAGE_PATH + "certificate_pf.pdf")) {
                if (resourceStream == null) {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
                }
                byte[] fileBytes = StreamUtils.copyToByteArray(resourceStream);
                return new ResponseEntity<>(fileBytes, HttpStatus.OK);
            } catch (IOException e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }

        Map<String, Object> queueElementFile;
        Queue<Map<String, Object>> tempQueue = new LinkedList<>();
        byte[] fileBytes = null;

        while ((queueElementFile = queueCert.poll()) != null) {
            String fileId = (String) queueElementFile.get("file");

            if (Objects.equals(fileUuid, fileId)) {
                fileBytes = (byte[]) queueElementFile.get("finger");
                break;
            } else {
                tempQueue.add(queueElementFile);
            }
        }

        queueCert.addAll(tempQueue);

        if (fileBytes != null) {
            return new ResponseEntity<>(fileBytes, HttpStatus.OK);
        }

        try (InputStream resourceStream = classLoader.getResourceAsStream(FILE_STORAGE_PATH + "signature.sgn")) {
            if (resourceStream == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            byte[] fileBytesss = StreamUtils.copyToByteArray(resourceStream);
            return new ResponseEntity<>(fileBytesss, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping(path = "/files", consumes = {"multipart/form-data", "application/octet-stream"})
    public ResponseEntity<Map<String, Object>> uploadFile(@RequestParam("file") MultipartFile file) {
        String generatedId = generateRandomHex(32, false);

        Map<String, Object> response = new HashMap<>();
        response.put("status", 200);
        response.put("type", "about:blank");
        response.put("title", "Успех");
        response.put("detail", "Успех POST /files");

        Map<String, String> fileObject = new HashMap<>();
        fileObject.put("id", generatedId);

        response.put("files", new Map[]{fileObject});

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/events/unconfirmed")
    public ResponseEntity<Map<String, Object>> getUnconfirmedEvent() {
        return emptyResponse();
    }

    @PostMapping("/events/confirm")
    public ResponseEntity<Map<String, Object>> handleConfirmedEvents(@RequestBody Map<String, Object> request) {
        Map<String, Object> responseEvent = new HashMap<>();
        responseEvent.put("status", 200);

        return ResponseEntity.status(HttpStatus.OK).body(responseEvent);
    }

    private Map<String, Object> handleUsigRegRequest(Map<String, Object> event) {
        String id = generateRandomHex(32, false);
        String code = "usig.reg.response";
        Map<String, Object> data1 = (Map<String, Object>) event.get("data");//
        List<Map<String, Object>> owners = (List<Map<String, java.lang.Object>>) data1.get("ВладельцыЭП");
        Map<String, Object> targetData = owners.get(0);
        Map<String, Object> responseEvent = new HashMap<>();
        responseEvent.put("id", id);
        responseEvent.put("code", "usig.reg.request");
        responseEvent.put("data", data1);
        responseEvent.put("created", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'").format(new Date()));
        responseEvent.put("consumer", Collections.singletonList("usig"));
        Instant now = Instant.now();
        Instant futureInstant = now.plusSeconds(10);
        String idowner = (String) targetData.get("ИдВладельцаЭП");
        queue.add(Map.of("id", id, "code", code, "time", futureInstant.toString(), "keys", idowner));

        return responseEvent;
    }

    private Map<String, Object> handleUsigTokenRequest(Map<String, Object> event) {
        String id = generateRandomHex(32, false);
        String code = "usig.token.response";

        Map<String, Object> data1 = (Map<String, Object>) event.get("data");//

        // Создание и заполнение данных события, как в предыдущей реализации
        Map<String, Object> responseEvent = new HashMap<>();
        responseEvent.put("id", id);
        responseEvent.put("code", "usig.token.request");
        responseEvent.put("data", data1);
        responseEvent.put("errors", null);
        responseEvent.put("created", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'").format(new Date()));
        responseEvent.put("consumer", Collections.singletonList("usig"));
        Instant now = Instant.now();
        Instant futureInstant = now.plusSeconds(10);
        String token = (String) data1.get("ИдСертификата");
        queue.add(Map.of("id", id, "code", code, "time", futureInstant.toString(), "keys", token));

//        logQueueContents();
        return responseEvent;

    }

    private Map<String, Object> handleUsigTokenActivateRequest(Map<String, Object> event) {
        String id = generateRandomHex(32, false);
        String code = "usig.token.activate.response";
        Map<String, Object> data1 = (Map<String, Object>) event.get("data");//
        Map<String, Object> responseEvent = new HashMap<>();
        responseEvent.put("id", id);
        responseEvent.put("code", "usig.token.activate.request");
        responseEvent.put("data", data1);
        responseEvent.put("errors", null);
        responseEvent.put("created", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'").format(new Date()));
        responseEvent.put("consumer", Collections.singletonList("usig"));
        Instant now = Instant.now();
        Instant futureInstant = now.plusSeconds(10);
        String token = (String) data1.get("Токен");
        queue.add(Map.of("id", id, "code", code, "time", futureInstant.toString(), "keys", token));

//        logQueueContents();
        return responseEvent;

    }

    private Map<String, Object> handleUsigSignHashRequest(Map<String, Object> event) {

        String id = generateRandomHex(32, false);
        String code = "usig.sign.hash.response";
        Map<String, Object> data1 = (Map<String, Object>) event.get("data");
        Map<String, Object> responseEvent = new HashMap<>();
        responseEvent.put("id", id);
        responseEvent.put("code", "usig.sign.hash.request");
        responseEvent.put("data", data1);
        responseEvent.put("errors", null);
        responseEvent.put("created", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'").format(new Date()));
        responseEvent.put("consumer", Collections.singletonList("usig"));
        Instant now = Instant.now();
        Instant futureInstant = now.plusSeconds(10);
        queue.add(Map.of("id", id, "code", code, "time", futureInstant.toString(), "keys", "куку"));

//        logQueueContents();
        return responseEvent;

    }

    private Map<String, Object> createUsigRegResponseData(Map<String, String> queueElement) throws Exception {

        byte[] fileBytes = generateSelfSignedCertificate();
        X509Certificate certificate = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(fileBytes));

        String thumbprint = getCertificateThumbprintSHA1(certificate);
        String Файл = generateRandomHex(32, false);
        queueCert.add(Map.of("finger",fileBytes,"file",Файл));

//        log.info("Отпечаток сертификата: " + thumbprint.toUpperCase());

        String ИдАбонента = generateRandomGuid().toLowerCase();
        String ВладельцыЭП = queueElement.get("keys").toUpperCase(); // брать  из  реквеста
//
//        String Файл = "00000000000000000000000000000011";
//        String ФайлПечатнойФормы = generateRandomHex(32, false);
        String ФайлПечатнойФормы = "00000000000000000000000000000010";
        String Отпечаток = thumbprint.toUpperCase();
        String ИдСертификата1 = generateRandomGuid().toUpperCase();
        String ИдКлючаСубъекта = generateRandomHex(40, true);
        Map<String, Object> fio = new HashMap<>();
        fio.put("Имя", "Эван");
        fio.put("Фамилия", "Эванов");
        fio.put("Отчество", "Эванович");
        Map<String, Object> сертификат = new HashMap<>();
        сертификат.put("Файл", Файл);
        сертификат.put("Отпечаток", Отпечаток);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date now = new Date();
        Date oneYearLater = new Date(now.getTime() + 365L * 24 * 60 * 60 * 1000);
        сертификат.put("ДатаНачала", dateFormat.format(now));
        сертификат.put("ДатаОкончания", dateFormat.format(oneYearLater));
        сертификат.put("ИдСертификата", ИдСертификата1);
        сертификат.put("ИдКлючаСубъекта", ИдКлючаСубъекта);
        сертификат.put("ФайлПечатнойФормы", ФайлПечатнойФормы);
        Map<String, Object> владелец = new HashMap<>();
        владелец.put("ФИО", fio);
        владелец.put("СНИЛС", "170-771-483 75");
        владелец.put("Сертификат", сертификат);
        владелец.put("ТребуетсяОтправкаПечатнойФормы", true);
        Map<String, Object> владельцыЭП = new HashMap<>();
        владельцыЭП.put(ВладельцыЭП, владелец);
        Map<String, Object> data = new HashMap<>();
        data.put("Сообщение", "Регистрация завершена успешно.");
        data.put("ИдАбонента", ИдАбонента);
        data.put("ВладельцыЭП", владельцыЭП);
        data.put("Сформировано", "2024-06-21T13:36:48Z");
        data.put("ДатаОкончанияЛицензии", "2124-06-22");

        return data;
    }

    private Map<String, Object> createUsigTokenResponseData(Map<String, String> queueElement) {

        String ИдСертификата = queueElement.get("keys");
        String token = generateRandomHex(32, false);
        Map<String, Object> data = new HashMap<>();
        data.put("Токен", token);
        data.put("ИдСертификата", ИдСертификата);

        return data;
    }

    private Map<String, Object> createUsigTokenActivateResponseData(Map<String, String> queueElement) {

        String токен = queueElement.get("keys");
        String активирован = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(new Date());
        Map<String, Object> data = new HashMap<>();
        data.put("Активирован", активирован);
        data.put("Токен", токен);

        return data;
    }


    private Map<String, Object> createSugnHashResponseData() {

        String токен = generateRandomHex(32, false);
        Map<String, Object> data = new HashMap<>();
        data.put("ФайлПодписи", токен);

        return data;
    }

    private ResponseEntity<Map<String, Object>> emptyResponse() {

        List<Map<String, Object>> events = new ArrayList<>();
        Map<String, Object> response = new HashMap<>();
        response.put("type", "about:blank");
        response.put("title", "Сведения о событиях");
        response.put("events", events);
        response.put("status", 200);

        return ResponseEntity.ok(response);
    }


    public static byte[] generateSelfSignedCertificate() throws Exception {
        // Добавление BouncyCastle в качестве провайдера безопасности
        Security.addProvider(new BouncyCastleProvider());

        // Установка параметров кривой ГОСТ
        ECNamedCurveParameterSpec spec = ECNamedCurveTable.getParameterSpec("Tc26-Gost-3410-12-256-paramSetA");

        // Генерация ключевой пары
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("ECGOST3410-2012", "BC");
        keyPairGenerator.initialize(spec);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        // Создание данных сертификата
        long now = System.currentTimeMillis();
        Date validAfterDate = new Date(now);
        Date expiresDate = new Date(now + (365L * 24 * 60 * 60 * 1000));

        // Установка полей
        String name = "Test Owner Qw";
        String nameSN = "Test";
        String nameG = "Owner Qw";
        String nameE = "iyanbarisov2@hr-link.ru";
        BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
        X500NameBuilder issuerBuilder = new X500NameBuilder(BCStyle.INSTANCE);

        String cname = "Тестовый АО КАЛУГА АСТРАЛ";
        String cnameO = "АО КАЛУГА АСТРАЛЛ";
        String cnameStreet = "пер. Теренинский д.6";
        String cnameL = "г. Калуга";
        String cnameS = "40 Калужская";
        String cnameC = "RU";

        issuerBuilder.addRDN(new ASN1ObjectIdentifier("1.2.643.100.1"), "1024001434049");
        issuerBuilder.addRDN(new ASN1ObjectIdentifier("1.2.643.3.131.1.1"), "004029017981");
        issuerBuilder.addRDN(BCStyle.C, cnameC);
        issuerBuilder.addRDN(BCStyle.SURNAME, cnameS);
        issuerBuilder.addRDN(BCStyle.L, cnameL);
        issuerBuilder.addRDN(BCStyle.STREET, cnameStreet);
        issuerBuilder.addRDN(BCStyle.O, cnameO);
        issuerBuilder.addRDN(BCStyle.CN, cname);

        X500Name issuer = issuerBuilder.build();

        // Создание поля Subject с дополнительным атрибутом OID
        X500NameBuilder subjectBuilder = new X500NameBuilder(BCStyle.INSTANCE);
        subjectBuilder.addRDN(BCStyle.E, nameE);
        subjectBuilder.addRDN(new ASN1ObjectIdentifier("1.2.643.100.3"), "16696475432"); // snils
        subjectBuilder.addRDN(new ASN1ObjectIdentifier("1.2.643.3.131.1.1"), "967490219141"); // inn
        subjectBuilder.addRDN(BCStyle.GIVENNAME, nameG);
        subjectBuilder.addRDN(BCStyle.SURNAME, nameSN);
        subjectBuilder.addRDN(BCStyle.CN, name);

        X500Name subject = subjectBuilder.build();

        // Создание SubjectPublicKeyInfo из публичного ключа
        SubjectPublicKeyInfo subjPubKeyInfo = SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded());

        // Создание сертификата с использованием BouncyCastle
        X509v3CertificateBuilder certificateBuilder = new JcaX509v3CertificateBuilder(
                issuer,
                serialNumber,
                validAfterDate,
                expiresDate,
                subject,
                subjPubKeyInfo
        );

        // Преобразование приватного ключа в AsymmetricKeyParameter
        AsymmetricKeyParameter privateKeyAsymKeyParam = PrivateKeyFactory.createKey(keyPair.getPrivate().getEncoded());

        // Создание ContentSigner для ГОСТ
        ContentSigner contentSigner = new BcECContentSignerBuilder(
                new DefaultSignatureAlgorithmIdentifierFinder().find("GOST3411-2012-256withECGOST3410-2012-256"),
                new DefaultDigestAlgorithmIdentifierFinder().find("GOST3411-2012-256")
        ).build(privateKeyAsymKeyParam);

        // Создание сертификата
        X509Certificate certificate = new JcaX509CertificateConverter().setProvider("BC").getCertificate(certificateBuilder.build(contentSigner));

        return certificate.getEncoded();
    }


    public static String getCertificateThumbprintSHA1(X509Certificate certificate) throws Exception {
        // Создаем инстанс MessageDigest с алгоритмом SHA-1
        MessageDigest md = MessageDigest.getInstance("SHA-1");

        // Вычисляем хэш (отпечаток) сертификата
        byte[] digest = md.digest(certificate.getEncoded());

        // Преобразуем хэш в строку 16-ричного представления
        StringBuilder hexString = new StringBuilder();
        for (byte b : digest) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        return hexString.toString();
    }
    private static void logQueueContents() {
        System.out.println("State Queue:");
        for (Map<String, String> map : queue) {
            System.out.println(map);
        }
    }
}



